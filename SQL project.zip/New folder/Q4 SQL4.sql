use WideWorldImporters


-- 1. Loss per order (order value - invoiced value)
WITH OrderLoss AS (
    SELECT
        o.OrderID,
        o.CustomerID,
        SUM(ol.Quantity * ol.UnitPrice)
          - COALESCE(SUM(il.Quantity * il.UnitPrice), 0) AS LossAmount
    FROM Sales.Orders o
    JOIN Sales.OrderLines ol
        ON ol.OrderID = o.OrderID
    LEFT JOIN Sales.Invoices i
        ON i.OrderID = o.OrderID
    LEFT JOIN Sales.InvoiceLines il
        ON il.InvoiceID = i.InvoiceID
    GROUP BY
        o.OrderID,
        o.CustomerID
),

-- 2. Loss per customer (sum of all their order losses)
CustomerLoss AS (
    SELECT
        c.CustomerID,
        c.CustomerName,
        cc.CustomerCategoryID,
        cc.CustomerCategoryName,
        SUM(ol.LossAmount) AS TotalLoss
    FROM OrderLoss ol
    JOIN Sales.Customers c
        ON c.CustomerID = ol.CustomerID
    JOIN Sales.CustomerCategories cc
        ON cc.CustomerCategoryID = c.CustomerCategoryID
    GROUP BY
        c.CustomerID,
        c.CustomerName,
        cc.CustomerCategoryID,
        cc.CustomerCategoryName
),

-- 3. Highest loss per customer category
MaxLossPerCategory AS (
    SELECT
        CustomerCategoryID,
        MAX(TotalLoss) AS MaxLoss
    FROM CustomerLoss
    GROUP BY CustomerCategoryID
)

-- 4. Final result: one row per category, with customer id & name
SELECT
    cl.CustomerCategoryID,
    cl.CustomerCategoryName,
    cl.CustomerID,
    cl.CustomerName,
    ml.MaxLoss AS HighestLoss
FROM MaxLossPerCategory ml
JOIN CustomerLoss cl
    ON cl.CustomerCategoryID = ml.CustomerCategoryID
   AND cl.TotalLoss = ml.MaxLoss
ORDER BY
    HighestLoss DESC;
