use SQLPlayground

USE SQLPlayground;

SELECT
    c.*
FROM
    Customer AS c
WHERE
    -- condition 1: customer bought ALL products
    NOT EXISTS (
        SELECT 1
        FROM Product AS p
        WHERE NOT EXISTS (
            SELECT 1
            FROM Purchase AS pu
            WHERE pu.CustomerId = c.CustomerId
              AND pu.ProductId  = p.ProductId
        )
    )
    -- condition 2: total purchased quantity > 50
    AND c.CustomerId IN (
        SELECT pu.CustomerId
        FROM Purchase AS pu
        GROUP BY pu.CustomerId
        HAVING SUM(pu.Qty) > 50   -- use your actual quantity column name
    );
