use WideWorldImporters


-- Q1: Orders vs Invoices Consistency Check - WideWorldImporters



-- Q1 COMPLETE QUERY - DEMONSTRATES FALSE RESULT
SELECT
    c.CustomerID,
    c.CustomerName,
    COUNT(DISTINCT o.OrderID) AS TotalNBOrders,
    COUNT(DISTINCT i.InvoiceID) AS TotalNBInvoices,
    SUM(ol.UnitPrice * ol.Quantity) AS OrdersTotalValue,
    SUM(il.UnitPrice * il.Quantity) AS InvoicesTotalValue,
    ABS(
        SUM(ol.UnitPrice * ol.Quantity)
        - SUM(il.UnitPrice * il.Quantity)
    ) AS AbsoluteValueDifference
FROM Sales.Customers AS c
JOIN Sales.Orders AS o
    ON o.CustomerID = c.CustomerID
JOIN Sales.OrderLines AS ol
    ON ol.OrderID = o.OrderID
LEFT JOIN Sales.Invoices AS i
    ON i.OrderID = o.OrderID
LEFT JOIN Sales.InvoiceLines AS il
    ON il.InvoiceID = i.InvoiceID
GROUP BY
    c.CustomerID,
    c.CustomerName
ORDER BY
    AbsoluteValueDifference DESC,
    TotalNBOrders ASC,
    CustomerName ASC;

