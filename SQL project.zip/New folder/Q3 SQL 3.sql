use WideWorldImporters

GO

IF OBJECT_ID('dbo.ReportCustomerTurnover', 'P') IS NOT NULL
    DROP PROCEDURE dbo.ReportCustomerTurnover;
GO

CREATE PROCEDURE dbo.ReportCustomerTurnover
    @Choice int = 1,     -- 1 = monthly, 2 = quarterly, 3 = yearly
    @Year   int = 2013   -- used only when Choice = 1 or 2
AS
BEGIN
    SET NOCOUNT ON;

    ------------------------------------------------------
    -- Choice 1: monthly turnover for a given year
    ------------------------------------------------------
    IF @Choice = 1
    BEGIN
        ;WITH Turnover AS
        (
            SELECT  c.CustomerName,
                    MONTH(i.InvoiceDate) AS MonthNo,
                    SUM(il.Quantity * il.UnitPrice) AS TurnoverAmount
            FROM Sales.Customers c
            LEFT JOIN Sales.Invoices i
                ON c.CustomerID = i.CustomerID
               AND YEAR(i.InvoiceDate) = @Year
            LEFT JOIN Sales.InvoiceLines il
                ON i.InvoiceID = il.InvoiceID
            GROUP BY c.CustomerName, MONTH(i.InvoiceDate)
        )
        SELECT  CustomerName,
                ISNULL([1], 0)  AS Jan,
                ISNULL([2], 0)  AS Feb,
                ISNULL([3], 0)  AS Mar,
                ISNULL([4], 0)  AS Apr,
                ISNULL([5], 0)  AS May,
                ISNULL([6], 0)  AS Jun,
                ISNULL([7], 0)  AS Jul,
                ISNULL([8], 0)  AS Aug,
                ISNULL([9], 0)  AS Sep,
                ISNULL([10], 0) AS Oct,
                ISNULL([11], 0) AS Nov,
                ISNULL([12], 0) AS [Dec]
        FROM Turnover
        PIVOT
        (
            MAX(TurnoverAmount) FOR MonthNo IN
            ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])
        ) AS p
        ORDER BY CustomerName;
    END

    ------------------------------------------------------
    -- Choice 2: quarterly turnover for a given year
    ------------------------------------------------------
    ELSE IF @Choice = 2
    BEGIN
        ;WITH Turnover AS
        (
            SELECT  c.CustomerName,
                    DATEPART(QUARTER, i.InvoiceDate) AS QuarterNo,
                    SUM(il.Quantity * il.UnitPrice) AS TurnoverAmount
            FROM Sales.Customers c
            LEFT JOIN Sales.Invoices i
                ON c.CustomerID = i.CustomerID
               AND YEAR(i.InvoiceDate) = @Year
            LEFT JOIN Sales.InvoiceLines il
                ON i.InvoiceID = il.InvoiceID
            GROUP BY c.CustomerName, DATEPART(QUARTER, i.InvoiceDate)
        )
        SELECT  CustomerName,
                ISNULL([1], 0) AS Q1,
                ISNULL([2], 0) AS Q2,
                ISNULL([3], 0) AS Q3,
                ISNULL([4], 0) AS Q4
        FROM Turnover
        PIVOT
        (
            MAX(TurnoverAmount) FOR QuarterNo IN ([1],[2],[3],[4])
        ) AS p
        ORDER BY CustomerName;
    END

    ------------------------------------------------------
    -- Choice 3: yearly turnover 2013�2016 (Year ignored)
    ------------------------------------------------------
    ELSE IF @Choice = 3
    BEGIN
        ;WITH Turnover AS
        (
            SELECT  c.CustomerName,
                    YEAR(i.InvoiceDate) AS YearNo,
                    SUM(il.Quantity * il.UnitPrice) AS TurnoverAmount
            FROM Sales.Customers c
            JOIN Sales.Invoices i
                ON c.CustomerID = i.CustomerID
            JOIN Sales.InvoiceLines il
                ON i.InvoiceID = il.InvoiceID
            WHERE YEAR(i.InvoiceDate) BETWEEN 2013 AND 2016
            GROUP BY c.CustomerName, YEAR(i.InvoiceDate)
        )
        SELECT  CustomerName,
                ISNULL([2013], 0) AS [2013],
                ISNULL([2014], 0) AS [2014],
                ISNULL([2015], 0) AS [2015],
                ISNULL([2016], 0) AS [2016]
        FROM Turnover
        PIVOT
        (
            MAX(TurnoverAmount) FOR YearNo IN ([2013],[2014],[2015],[2016])
        ) AS p
        ORDER BY CustomerName;
    END

    ELSE
    BEGIN
        RAISERROR('Choice must be 1 (monthly), 2 (quarterly), or 3 (yearly).', 16, 1);
    END
END;
GO

