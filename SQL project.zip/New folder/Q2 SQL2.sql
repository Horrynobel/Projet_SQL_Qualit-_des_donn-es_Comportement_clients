 use WideWorldImporters

 -- Identify the first InvoiceLine of his first Invoice
SELECT
    i.CustomerID,
    c.CustomerName,
    SUM(il.UnitPrice * il.Quantity) AS InvoiceTotal
FROM Sales.Invoices AS i
JOIN Sales.Customers AS c
    ON c.CustomerID = i.CustomerID
JOIN Sales.InvoiceLines AS il
    ON il.InvoiceID = i.InvoiceID
WHERE i.CustomerID = 1060
  AND i.InvoiceID = (
        SELECT TOP (1) i2.InvoiceID
        FROM Sales.Invoices AS i2
        WHERE i2.CustomerID = 1060
        ORDER BY i2.InvoiceID ASC
  )
GROUP BY
    i.CustomerID,
    c.CustomerName;

	--Update that InvoiceLine, increasing UnitPrice by 20

UPDATE il
SET il.UnitPrice = il.UnitPrice + 20
FROM Sales.InvoiceLines AS il
WHERE il.InvoiceLineID = (
    SELECT TOP (1) il2.InvoiceLineID
    FROM Sales.Invoices AS i
    JOIN Sales.InvoiceLines AS il2
        ON il2.InvoiceID = i.InvoiceID
    WHERE i.CustomerID = 1060
    ORDER BY i.InvoiceID ASC, il2.InvoiceLineID ASC
);
